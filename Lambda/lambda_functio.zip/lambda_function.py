import json
import boto3
from datetime import datetime
from uuid import uuid4

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('TodoTable')

def lambda_handler(event, context):
    # Set CORS headers
    headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Content-Type': 'application/json'
    }
    
    # Handle OPTIONS request
    if event.get('httpMethod') == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({})
        }
    
    try:
        # Parse path parameters and body
        path_params = event.get('pathParameters', {}) or {}
        task_id = path_params.get('id')
        body = json.loads(event.get('body', '{}'))
        
        # Route the request
        if event['httpMethod'] == 'GET':
            if not task_id:
                # GET /todos - List all items
                items = table.scan().get('Items', [])
                return {
                    'statusCode': 200,
                    'headers': headers,
                    'body': json.dumps(items)
                }
            else:
                # GET /todos/{id} - Get single item
                response = table.get_item(Key={'TaskId': task_id})
                if 'Item' not in response:
                    return {
                        'statusCode': 404,
                        'headers': headers,
                        'body': json.dumps({'error': 'Task not found'})
                    }
                return {
                    'statusCode': 200,
                    'headers': headers,
                    'body': json.dumps(response['Item'])
                }
                
        elif event['httpMethod'] == 'POST':
            # POST /todos - Create new item
            if not body.get('text'):
                return {
                    'statusCode': 400,
                    'headers': headers,
                    'body': json.dumps({'error': 'text field is required'})
                }
                
            new_task = {
                'TaskId': str(uuid4()),
                'text': body['text'],
                'completed': False,
                'createdAt': datetime.now().isoformat(),
                'updatedAt': datetime.now().isoformat()
            }
            table.put_item(Item=new_task)
            return {
                'statusCode': 201,
                'headers': headers,
                'body': json.dumps(new_task)
            }
            
        elif event['httpMethod'] == 'PUT':
            # PUT /todos/{id} - Update item
            if not task_id:
                return {
                    'statusCode': 400,
                    'headers': headers,
                    'body': json.dumps({'error': 'Task ID is required'})
                }
                
            # Get existing item first
            existing = table.get_item(Key={'TaskId': task_id})
            if 'Item' not in existing:
                return {
                    'statusCode': 404,
                    'headers': headers,
                    'body': json.dumps({'error': 'Task not found'})
                }
                
            updated_task = {
                'TaskId': task_id,
                'text': body.get('text', existing['Item'].get('text', '')),
                'completed': body.get('completed', existing['Item'].get('completed', False)),
                'createdAt': existing['Item'].get('createdAt', datetime.now().isoformat()),
                'updatedAt': datetime.now().isoformat()
            }
            table.put_item(Item=updated_task)
            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps(updated_task)
            }
            
        elif event['httpMethod'] == 'DELETE':
            # DELETE /todos/{id} - Delete item
            if not task_id:
                return {
                    'statusCode': 400,
                    'headers': headers,
                    'body': json.dumps({'error': 'Task ID is required'})
                }
                
            # Verify item exists first
            existing = table.get_item(Key={'TaskId': task_id})
            if 'Item' not in existing:
                return {
                    'statusCode': 404,
                    'headers': headers,
                    'body': json.dumps({'error': 'Task not found'})
                }
                
            table.delete_item(Key={'TaskId': task_id})
            return {
                'statusCode': 204,
                'headers': headers,
                'body': json.dumps({})
            }
            
    except json.JSONDecodeError:
        return {
            'statusCode': 400,
            'headers': headers,
            'body': json.dumps({'error': 'Invalid JSON format'})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({'error': str(e)})
        }